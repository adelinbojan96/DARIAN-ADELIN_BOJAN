-- DROP SCHEMA public;

CREATE SCHEMA public AUTHORIZATION pg_database_owner;

COMMENT ON SCHEMA public IS 'standard public schema';
-- public."comments" definition

-- Drop table

-- DROP TABLE public."comments";

CREATE TABLE public."comments" (
	id_comment int4 NOT NULL,
	"text" varchar NOT NULL,
	"date" timestamp NOT NULL,
	id_user int4 NOT NULL,
	id_pet int4 NOT NULL,
	CONSTRAINT comments_pk PRIMARY KEY (id_comment)
);

-- Permissions

ALTER TABLE public."comments" OWNER TO postgres;
GRANT ALL ON TABLE public."comments" TO postgres;


-- public.pet definition

-- Drop table

-- DROP TABLE public.pet;

CREATE TABLE public.pet (
	id_pet int4 NOT NULL,
	"name" varchar NOT NULL,
	animal_type varchar NOT NULL,
	breed varchar NOT NULL,
	age int4 NOT NULL,
	id_store int4 NOT NULL,
	id_history int4 NULL,
	image bytea NULL,
	CONSTRAINT pet_pk PRIMARY KEY (id_pet),
	CONSTRAINT pet_un UNIQUE (id_history)
);

-- Permissions

ALTER TABLE public.pet OWNER TO postgres;
GRANT ALL ON TABLE public.pet TO postgres;
GRANT REFERENCES, SELECT, UPDATE ON TABLE public.pet TO pg_write_server_files;
GRANT REFERENCES, SELECT, UPDATE ON TABLE public.pet TO pg_write_all_data;
GRANT REFERENCES, SELECT, UPDATE ON TABLE public.pet TO pg_use_reserved_connections;
GRANT REFERENCES, SELECT, UPDATE ON TABLE public.pet TO pg_stat_scan_tables;
GRANT REFERENCES, SELECT, UPDATE ON TABLE public.pet TO pg_signal_backend;
GRANT REFERENCES, SELECT, UPDATE ON TABLE public.pet TO pg_read_server_files;
GRANT REFERENCES, SELECT, UPDATE ON TABLE public.pet TO pg_read_all_stats;
GRANT REFERENCES, SELECT, UPDATE ON TABLE public.pet TO pg_read_all_settings;
GRANT REFERENCES, SELECT, UPDATE ON TABLE public.pet TO pg_read_all_data;
GRANT REFERENCES, SELECT, UPDATE ON TABLE public.pet TO pg_monitor;
GRANT REFERENCES, SELECT, UPDATE ON TABLE public.pet TO pg_execute_server_program;
GRANT REFERENCES, SELECT, UPDATE ON TABLE public.pet TO pg_database_owner;
GRANT REFERENCES, SELECT, UPDATE ON TABLE public.pet TO pg_create_subscription;
GRANT REFERENCES, SELECT, UPDATE ON TABLE public.pet TO pg_checkpoint;
GRANT INSERT(image) ON public.pet TO pg_write_server_files;
GRANT INSERT(image) ON public.pet TO pg_write_all_data;
GRANT INSERT(image) ON public.pet TO pg_use_reserved_connections;
GRANT INSERT(image) ON public.pet TO pg_stat_scan_tables;
GRANT INSERT(image) ON public.pet TO pg_signal_backend;
GRANT INSERT(image) ON public.pet TO pg_read_server_files;
GRANT INSERT(image) ON public.pet TO pg_read_all_stats;
GRANT INSERT(image) ON public.pet TO pg_read_all_settings;
GRANT INSERT(image) ON public.pet TO pg_read_all_data;
GRANT INSERT(image) ON public.pet TO pg_monitor;
GRANT INSERT(image) ON public.pet TO pg_execute_server_program;
GRANT INSERT(image) ON public.pet TO pg_database_owner;
GRANT INSERT(image) ON public.pet TO pg_create_subscription;
GRANT INSERT(image) ON public.pet TO pg_checkpoint;


-- public.pet_history definition

-- Drop table

-- DROP TABLE public.pet_history;

CREATE TABLE public.pet_history (
	id_history int4 NOT NULL,
	years_in_shop int4 NOT NULL,
	previous_health_issues bool NOT NULL,
	pet_behaviour_desc varchar NULL,
	previous_medical_treatment_desc varchar NULL,
	CONSTRAINT pet_history_pk PRIMARY KEY (id_history)
);

-- Permissions

ALTER TABLE public.pet_history OWNER TO postgres;
GRANT ALL ON TABLE public.pet_history TO postgres;


-- public.store definition

-- Drop table

-- DROP TABLE public.store;

CREATE TABLE public.store (
	id_store int4 NOT NULL,
	"name" varchar NOT NULL,
	years_of_activity int4 NOT NULL,
	city varchar NOT NULL,
	manager_code varchar NOT NULL,
	CONSTRAINT id_greater CHECK ((id_store > 0)),
	CONSTRAINT store_check CHECK ((length((manager_code)::text) > 7)),
	CONSTRAINT store_pk PRIMARY KEY (id_store)
);

-- Permissions

ALTER TABLE public.store OWNER TO postgres;
GRANT ALL ON TABLE public.store TO postgres;


-- public.users definition

-- Drop table

-- DROP TABLE public.users;

CREATE TABLE public.users (
	id_user int4 NOT NULL,
	username varchar NOT NULL,
	"password" varchar NOT NULL,
	email varchar NOT NULL,
	phone_number varchar NULL,
	user_image bytea NULL,
	color_preferred varchar NOT NULL DEFAULT 'Blue'::character varying,
	CONSTRAINT users_pk PRIMARY KEY (id_user)
);

-- Permissions

ALTER TABLE public.users OWNER TO postgres;
GRANT ALL ON TABLE public.users TO postgres;




-- Permissions

GRANT ALL ON SCHEMA public TO pg_database_owner;
GRANT USAGE ON SCHEMA public TO public;