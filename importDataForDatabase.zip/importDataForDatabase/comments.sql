INSERT INTO public."comments" (id_comment,"text","date",id_user,id_pet) VALUES
	 (3,'I would like to take Misu home.','2023-12-28 16:39:27.128',5,1),
	 (5,'It is very serious','2023-12-29 16:38:31.153',1,15),
	 (6,'I like polar bears','2023-12-29 16:40:06.961',1,16),
	 (7,'Seems scary but I would want one.','2023-12-29 19:43:27.353',1,11),
	 (9,'i want bruce','2024-01-05 15:14:25.934',1,8),
	 (10,'Please I want Wilson.','2024-01-06 10:01:19.08',1,3),
	 (11,'This kangaroo is what I''ve wanted!','2024-01-08 20:02:35.474',1,21),
	 (17,'llolololo','2024-01-09 13:21:03.569',6,17),
	 (12,'I wrote here some info.','2024-01-09 13:20:32.258',6,6);
