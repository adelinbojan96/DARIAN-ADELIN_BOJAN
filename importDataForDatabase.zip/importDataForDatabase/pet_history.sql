INSERT INTO public.pet_history (id_history,years_in_shop,previous_health_issues,pet_behaviour_desc,previous_medical_treatment_desc) VALUES
	 (1,2,false,'Extremely friendly',NULL),
	 (3,1,false,'Sometimes dangereous',''),
	 (5,0,false,'He is lovely and would love an owner with a tough personality',NULL),
	 (6,1,true,'Might look friendly, but won''t be if enough food is not provided','Had a surgery recently'),
	 (7,0,false,'Recently added in store, wants nothing but the warm welcome in a new home ',NULL),
	 (2,3,true,'Loves families, children','He had a severe injury in the back, he had physical therapy sessions and took Anti-Inflammatory Medications'),
	 (8,1,false,'Most wanted fish, a bit needy',NULL),
	 (4,2,false,'Does not enjoy staying still, but a good and reliable companion',NULL),
	 (10,2,false,'Good companion, but not ok to be near farms',NULL),
	 (11,1,false,'Likes playing with dogs',NULL);
INSERT INTO public.pet_history (id_history,years_in_shop,previous_health_issues,pet_behaviour_desc,previous_medical_treatment_desc) VALUES
	 (12,0,false,'Recently added, passionate about the future',NULL),
	 (13,2,false,'Wants a new home, new people, cold conditions',NULL),
	 (14,1,true,'Very serious, wants a nationalist family','Received pills for fever months ago'),
	 (15,2,false,'Extremely needy, loves London',NULL),
	 (9,4,true,'Extremely powerful, loves looking at people','Had medical surgery after he fought a big octopus'),
	 (16,2,true,'He talks a lot (the left one), was being used to talk with the other parrot','Once fought the other parrot, got small medical treatments'),
	 (17,1,false,'Larry is the calmest in the store.',NULL),
	 (18,0,false,'Mocha enjoys nature, loves butterflies',NULL),
	 (19,0,false,'Mocha''s little brother, loves nature even more than his brother',NULL),
	 (20,1,false,'Ken is a simple kangaroo, nothing more to add',NULL);
INSERT INTO public.pet_history (id_history,years_in_shop,previous_health_issues,pet_behaviour_desc,previous_medical_treatment_desc) VALUES
	 (21,1,true,'Loves running, loves adventures','Was hit in the head, but after 1 month of special treatment she is perfectly fine'),
	 (22,0,false,'Friendly being, wants caring family',NULL),
	 (23,4,false,'Very ambitious, loves fighting. He mostly thinks about attaining his goals.',''),
	 (24,1,true,'One of the most magnificent looking pets from our shop. Loves to be cuddled.','Was injured when tried to eat something, but later he was saved and rescued by some people.'),
	 (25,2,false,'Needs a big swimming pool, enjoys playing with kids.',''),
	 (26,1,false,'He is very gentle, unfortunately does not have a picture',NULL),
	 (27,1,false,'Very polite, had a classy family. Used with respectuos people.',NULL),
	 (28,1,true,'Vito has had tough times throughout his journey, now he is looking for a new and wealthy family.','Many times he was caught protecting his sisters, brothers, yet he was betrayed.Offered medical support from us.'),
	 (29,1,false,'Very calm, loves meetings and needs a family who likes classical music.',NULL),
	 (30,1,false,'Powerful, yet modest','');
