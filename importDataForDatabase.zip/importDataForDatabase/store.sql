INSERT INTO public.store (id_store,"name",years_of_activity,city,manager_code) VALUES
	 (1,'PetPal Paradise
',3,'Budapest','8*KlUrMn'),
	 (2,'The Pet Adoption Plaza',9,'Milano','OpJgBy53'),
	 (3,'The Adoption Nook',5,'Cluj-Napoca','QwErTyIo'),
	 (4,'Adoptable Companions Corner',14,'Chicago','88JkpWrS'),
	 (5,'Bark Avenue Adoption Center',2,'Berlin','unb7jsdg');
